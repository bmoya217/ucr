#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"


vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& same_side_normal,int recursion_depth) const
{
    vec3 color;
    if(recursion_depth < 4){
    	Hit hit;
    	Object* closest = world.Closest_Intersection(ray, hit);

    	vec3 next_intersection = intersection_point + hit.t*same_side_normal;

    	Ray next_ray;
    	next_ray.endpoint = intersection_point;
    	next_ray.direction = same_side_normal.normalized();

	    if(closest != NULL)
	    	return color + Shade_Surface(next_ray, next_intersection, closest->Normal(next_intersection), recursion_depth+1)/(recursion_depth+1);
	    else
	    	return 0;
    }
    else
    	return color;
}
 